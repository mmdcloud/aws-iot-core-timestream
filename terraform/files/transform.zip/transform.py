import json
import base64

def lambda_handler(event, context):
    output = []
    
    for record in event['Records']:
        # Decode the Kinesis data
        payload = base64.b64decode(record['kinesis']['data']).decode('utf-8')
        
        # Transform the data (add your logic here)
        transformed_data = json.loads(payload)
        
        # Add processing logic here
        print(f"Processing record: {transformed_data}")
        
        output.append({
            'recordId': record['recordId'],
            'result': 'Ok',
            'data': record['kinesis']['data']
        })
    
    return {'records': output}